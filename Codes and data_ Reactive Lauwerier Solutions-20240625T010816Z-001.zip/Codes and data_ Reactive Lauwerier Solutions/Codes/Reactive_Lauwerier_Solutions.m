% Code: Solutions for Thermally-driven Reactive Transport and Porosity 
% Evolution in Geothermal Systems ("Reactive Lauwerier Problem”) 
clear all ; close all; clc
tic

dr = 10;
r = [0 1e-10 1e-3 1e-2 1e-1 1*dr:dr:3000];
dr_vec = [(r(2:end) - r(1:end-1))]; 
Radial_coordinate_r = r;

t =  [200 10000 100000];
dt = 1;
sec_yr = 3600*365*24;
t = t.*sec_yr;
dt = dt.*sec_yr;

theta0 = 0.05;
rhof = 1000;
cpf = 4200;
rhor = 2400;
cpr = 1300;
kr = 3;
lambda = 1E-6; 
% lambda = 5E-10; 
csol = 2.7027e+04;
% csol = 3.7027e+04;
H = 4;
As = 10;
% As = 1e4;
Q = 500/(3600*24);  % Volumetric flow rate 

beta_caco3 = -0.075;
% beta_sio2 = 0.04;
Dhr = kr/(rhor*cpr);
T0 = 20;
Tin = 60;
Delcs = abs(beta_caco3*(Tin-T0));
del = pi*lambda*H*As/Q;
Zeta = kr/(Q*rhof*cpf)*pi./(sqrt(Dhr.*t));
solid = lambda*As/csol;

colors=[[0, 0.4470, 0.7410]	;[0.9290, 0.6940, 0.1250];[0.6350, 0.0780, 0.1840]];

Temperature_T_mtrx(1:numel(t), 1:numel(r)) = 0;
Disequilibrium_Capital_Lambda_diss_mtrx(1:numel(t), 1:numel(r)) = 0;
Porosity_theta_Nonequilibrium_sol_diss_mtrx(1:numel(t), 1:numel(r)) = 0;
Porosity_theta_equilibrium_sol_diss_mtrx(1:numel(t), 1:numel(r)) = 0;

% #### Temperature #####%
%########################
subplot(1,3,1)
for i=1:numel(t)

    T = T0+(Tin-T0).*erfc(Zeta(i).*r.^2) ;

  plot(r,T,'color',colors(i,:),'linewidth',2)
   hold on
   l_string(i)=({['$$t=$$',num2str(t(i)/(sec_yr*1000),3),' kyr']});

   Temperature_T_mtrx(i,:) = T;
end
set(gca,'fontsize',18,'TickLabelInterpreter','latex');
ylabel(gca,'$$T\,(^oC)$$','fontsize',22,'Interpreter','latex'); 
xlabel(gca,'$$r\; (m)$$','fontsize',22,'Interpreter','latex');
% xlim([0 3000])

axis square
l = legend(l_string(:),'fontsize',18,'Interpreter','latex');

% #### Disequilibrium #####%
%#####################
subplot(1,3,2)
beta_sym = sym(beta_caco3);
del_sym = sym(del);
r_sym = sym(r);

for i=1:numel(t)  
Zeta_sym = sym(Zeta(i));

% ##### Asymptotic Expansion % #####

trm1 =  beta_sym*(Tin-T0)/sqrt(pi).*exp(-del_sym.*r_sym.^2);
trm2 = (exp(-Zeta_sym^2.*r_sym.^4 + del_sym.*r_sym.^2)./(del_sym./(2*Zeta_sym)-Zeta_sym.*r_sym.^2) - 2*Zeta_sym/del_sym);
Lambda = (trm1.*trm2);
Disequilibrium_Capital_Lambda_diss_mtrx(i,:) = Lambda;

% % % ##### The Analytic Solution % #####
% 
% trm_exp = beta_sym*(Tin-T0).*exp(del_sym^2/(4*Omega_sym^2)-del_sym.*r_sym.^2);
% trm_erf = (erf(Omega_sym.*r_sym.^2 - del_sym/(2*Omega_sym)) + erf(del_sym/(2*Omega_sym)));
% Lambda = -double(vpa(trm_erf.*trm_exp,3000));  % 10000 with 3000
% 
% 
% plot(r,Lambda,'r','linewidth',2)
% hold on
 
plot(r,Lambda./Delcs,'color',colors(i,:),'linewidth',2)
hold on

end

set(gca,'fontsize',18,'TickLabelInterpreter','latex');
ylabel(gca,'$$\Lambda/\Delta c_{\rm{s}} $$','fontsize',22,'Interpreter','latex'); 
xlabel(gca,'$$r\; (m)$$','fontsize',22,'Interpreter','latex');
axis square
% xlim([0 3000])

% #### Porosity #####%
%#####################
subplot(1,3,3)

beta_sym = sym(beta_caco3);
del_sym = sym(del);
r_sym = sym(r);

% % % ##### The Analytic Solution % #####

for i=1:numel(t)
    
Fac = 4/del^2*beta_caco3.*Zeta(i)*solid*(Tin-T0)*t(i);

Trm1 = -(del.*Zeta(i).*r.^2).*(erf(Zeta(i).*r.^2)-1);

Trm4 = -1/sqrt(pi)*del.*exp(-Zeta(i)^2.*r.^4);

Trm5 = 1/sqrt(pi)*del.*exp(-del.*r.^2);

Trm6 = Zeta(i).*(erf(Zeta(i).*r.^2)-1);

omega_sym = sym(Zeta(i));

Trm2 = -omega_sym.*exp(1/4*del_sym.*(del_sym./omega_sym^2-4.*r_sym.^2)).*erf(omega_sym.*r_sym.^2-del_sym/(2*omega_sym));

Trm3 = -omega_sym*erf(del_sym/(2*omega_sym)).*exp(1/4*del_sym.*(del_sym./omega_sym^2-4.*r_sym.^2));

theta = Fac.*(Trm1+Trm2+Trm3+Trm4+Trm5+Trm6)+theta0;

theta = double(theta);
plot(r,theta,'color',colors(i,:),'linewidth',2) 
hold on
end

% %################# Solution by integration #########
% %###################################################
theta_num = theta0; t_track = 0;
for i=1:numel(t)  
while  t_track < t(i)
t_track = t_track + dt;

    Zeta_num = kr/(Q*rhof*cpf)*pi./(sqrt(Dhr.*t_track));
    
omega_sym = sym(Zeta_num);

Lambda = 1/sqrt(pi)*beta_caco3*(Tin-T0).*exp(-del_sym.*r_sym.^2).*(-(2*omega_sym/del_sym)...
    +exp(del_sym.*r_sym.^2-omega_sym^2.*r_sym.^4).*(1./(del_sym./(2*omega_sym)-omega_sym.*r_sym.^2)));

Lambda = double(Lambda);

theta_num = theta_num - solid.*Lambda.*dt;
end
plot(r,theta_num,'color',colors(i,:),'linewidth',2) 
hold on
end

set(gca,'fontsize',18,'TickLabelInterpreter','latex');
ylabel(gca,'$$\theta$$','fontsize',22,'Interpreter','latex'); 
xlabel(gca,'$$r\; (m)$$','fontsize',22,'Interpreter','latex');
axis square

toc
