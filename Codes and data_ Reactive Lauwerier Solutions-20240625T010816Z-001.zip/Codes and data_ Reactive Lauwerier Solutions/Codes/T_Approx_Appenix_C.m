clear all ; clc

dr = 10;
r = [1e-10 1e-3 1e-2 1e-1 1*dr:dr:3000];

t =  [10 100 1000];
dt = 1;
sec_yr = 3600*365*24;
t = t.*sec_yr;
dt = dt.*sec_yr;

theta0 = 0.05;
rhof = 1000;
cpf = 4200;
rhor = 2400;
cpr = 1300;
kr = 3;
H = 4;
Q = 500/(3600*24);  % Volumetric flow rate 

Dhr = kr/(rhor*cpr);
Ts = 20;
Tin = 60;

Zeta = kr/(Q*rhof*cpf)*pi./(sqrt(Dhr.*t));
t_tag2 = kr*H*pi.*r.^2./(cpf*rhof*Q);
colors=[[0, 0, 1]	;[1, 0, 0]];

for i=1:numel(t)
t_tag1 = Dhr*t(i);
t_tag = t_tag1 - t_tag2;
t_tag(t_tag<0) = 0;
Zeta_tag = kr/(Q*rhof*cpf)*pi./(sqrt(t_tag));

   T_hut_tag =Ts +(Tin-Ts).*erfc(Zeta_tag.*r.^2) ;
   plot(r,T_hut_tag,'-','color',colors(2,:),'linewidth',2)
   hold on

   T_hut = Ts +(Tin-Ts).*erfc(Zeta(i).*r.^2) ;
   plot(r,T_hut,'color',colors(1,:),'linewidth',2)
   hold on

annotation('textbox', [0.1, 0.2, 0.1, 0.1], 'String', ({['$$t=$$',num2str(t(i)/sec_yr,4),' yr']}),'LineStyle','none','fontsize',24,'Interpreter','latex')

end

set(gca,'fontsize',28,'TickLabelInterpreter','latex');
ylabel(gca,'$$\hat{T}\,(^oC)$$','fontsize',30,'Interpreter','latex'); 
xlabel(gca,'$$r\; (m)$$','fontsize',30,'Interpreter','latex');
xlim([0 1000])
yticks([20 30 40 50 60])
axis square
l = legend('Complete solution','Solution with $t''=t$','fontsize',28,'Interpreter','latex');
pbaspect([1.15 1 1])

