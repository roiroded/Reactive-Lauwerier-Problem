clear all 
clc
tic


n_diss = [3 8 20];
n_prec = [2  4 8];
theta0 = [0.05 0.2];
R = [ 3000];
t_plot =  [200:100:100000];

load('C:\Users\rr344\Dropbox\Reactive transport in geothermal system\Matlab_data\Porosity_theta_Nonequilibrium_sol_prec_mtrx.mat')
load('C:\Users\rr344\Dropbox\Reactive transport in geothermal system\Matlab_data\Porosity_theta_Nonequilibrium_sol_diss_mtrx.mat')

Porosity_theta_Nonequilibrium_sol_prec_mtrx = Porosity_theta_Nonequilibrium_sol_prec_mtrx(t_plot,:);
Porosity_theta_Nonequilibrium_sol_diss_mtrx = Porosity_theta_Nonequilibrium_sol_diss_mtrx(t_plot,:);

load('C:\Users\rr344\Dropbox\Reactive transport in geothermal system\Matlab_data\Radial_coordinate_r.mat')

r = Radial_coordinate_r;

for k=1:numel(R)

[indxR]=find(r(r<=R(k)));

Porosity_theta_Nonequilibrium_sol_diss_mtrx1 = Porosity_theta_Nonequilibrium_sol_diss_mtrx(:,1:(max(indxR)));
Porosity_theta_Nonequilibrium_sol_prec_mtrx1 = Porosity_theta_Nonequilibrium_sol_prec_mtrx(:,1:(max(indxR))) +0.15;
r = r(:,1:(max(indxR)));
dr_vec = [r(1,1) r(2:end)-r(1:end-1)];
dr_vec = [r(1,1)/2 (dr_vec(1:end-1)+dr_vec(2:end))./2 (dr_vec(end-1)+dr_vec(end))./4];

% colors=[[0, 0.4470, 0.7410];[0.4660, 0.6740, 0.1880];[0.9290, 0.6940, 0.1250];[0.6350, 0.0780, 0.1840]];
colors1=[[254,129,129];[254,46,46];[182,32,32]]./255;
colors2=[[204, 249, 255];[85, 208, 255];[0, 128, 191]]./255;


for j=1:numel(n_diss)
for i=1:numel(t_plot)

perm_up = [1 (Porosity_theta_Nonequilibrium_sol_diss_mtrx1(i,:)./theta0(1)).^n_diss(j)];
perm_dwn = [1 (Porosity_theta_Nonequilibrium_sol_prec_mtrx1(i,:)./theta0(2)).^n_prec(j)];

perm_eff_up(j,i) = 1./(sum(dr_vec./(perm_up.*R(k))));
perm_eff_dwn(j,i) = 1./(sum(dr_vec./(perm_dwn*R(k))));

end
string_n_diss = ({['$$n=$$',num2str(n_diss(j))]});
string_n_prec = ({['$$n=$$',num2str(n_prec(j))]});
annotation('textbox', [0.5, 0.2, 0.1, 0.1], 'String', string_n_diss,'LineStyle','none','fontsize',20,'Interpreter','latex')
annotation('textbox', [0.5, 0.2, 0.1, 0.1], 'String', string_n_prec,'LineStyle','none','fontsize',20,'Interpreter','latex')
end

subplot(1,numel(R),k)
for j=1:numel(n_diss)
plot([0 t_plot/1000],[1 perm_eff_up(j,:)],'-','color',colors1(j,:),'linewidth',2), 
hold on
plot([0 t_plot/1000],[1 perm_eff_dwn(j,:)],'-','color',colors2(j,:),'linewidth',2), 
hold on
plot([0 t_plot(end)/1000],[1 1],'--k','linewidth',3)

set(gca,'fontsize',26,'TickLabelInterpreter','latex');
ylabel(gca,'$$k_{\rm{eff}}/k_0$$','fontsize',32,'Interpreter','latex'); 
xlabel(gca,'$$t\; \rm{(kyr)}$$','fontsize',32,'Interpreter','latex');
end

axis square
axis tight
ylim([0 6.2])
yticks([0 0.5 1 2 4 6])
string = ({['$$k_{\rm{eff}}(R=$$',num2str(R(k)/1000,4),'$$\;\rm{km})$$']});
annotation('textbox', [0.1, 0.2, 0.1, 0.1], 'String', string,'LineStyle','none','fontsize',20,'Interpreter','latex')

annotation('textbox', [0.3, 0.2, 0.1, 0.1], 'String', 'Carbonate dissolution','LineStyle','none','fontsize',20,'Interpreter','latex')
annotation('textbox', [0.4, 0.2, 0.1, 0.1], 'String', 'Silica precipitation','LineStyle','none','fontsize',20,'Interpreter','latex')

end



